﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Repop_Companion.App_Code;
using Repop_Companion.DataModels;

public partial class $relurlnamespace$_$safeitemname$ : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {

} // method Page_Load
} // class $relurlnamespace$_$safeitemname$